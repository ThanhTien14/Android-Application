package com.example.todolistapp;

import android.annotation.SuppressLint;
import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        Button btnSubmit = findViewById(R.id.button);
        btnSubmit.setOnClickListener(v -> {
            EditText editText = findViewById(R.id.editTextText);
            TextView textView = findViewById(R.id.textView2);

            // Lấy giá trị từ EditText và chuyển sang double
            String input = editText.getText().toString();

            double kg = Double.parseDouble(input);
            // Chuyển đổi kg sang pound (1kg = 2.20462 pound)
            double pounds = kg * 2.20462;
            // Làm tròn đến 2 chữ số thập phân
            @SuppressLint("DefaultLocale") String result = String.format("%.2f pounds", pounds);
            textView.setText(result);
        });
    }
}